package com.ecommerce.userservice.dto;

import lombok.Data;

@Data
public class RegistroDto {
    private String username;
    private String email;
    private String password;
}
